var DEF_ROUTE_TAG       = '39';
var DEF_ROUTE_TITLE     = '39';
var DEF_DIR_TAG         = 'in';
var DEF_DIR_TITLE       = 'Inbound';
var DEF_STOP_TAG        = '8750';
var DEF_STOP_TITLE      = 'Forest Hills Station - Departure (Stop 8750)';

var webserviceURLBase = 'http://webservices.nextbus.com/service/publicXMLFeed?a=mbta&';
var predictionURLBase = webserviceURLBase + "command=predictions&";

var daysOfWeek      = new Array("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday");
var monthsOfYear    = new Array("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");

var timerInterval = null;
var prefRouteTag;
var prefRouteTitle;
var prefDirectionTag;
var prefDirectionTitle;
var prefStopTag;
var prefStopTitle;
var widgetId;

function changeDirection (elem) {
    savePrefs();
    updateUIRoutes();

	var directionObj = getCurrentDirectionObject();
	if (directionObj) {
        var stopsList = directionObj.getStops();
        var stopsLength = stopsList.length;
        var stopHTML = '';
        var tag;
        var shortTitle;
        while(stopsLength--){
            tag = stopsList[stopsLength].getStopTag();
            shortTitle = stopsList[stopsLength].getStopTitle();
            stopHTML += createOptionTag(tag, shortTitle);
        }
        
        $("#popupStop").html(stopHTML);
        $("#popupStop").val(prefStopTag);
        
        changeStop();
    }
}

function changeRoute () {
    savePrefs();
    updateUIRoutes();
    
	var routeObj = getCurrentRouteObject();
	var directionsList = routeObj.getDirections();
	var directionsLength = directionsList.length;
	var directionHTML = '';
	var tag;
	var shortTitle;
	while(directionsLength--){
		tag = directionsList[directionsLength].getDirectionTag();
		title = directionsList[directionsLength].getDirectionTitle();
		directionHTML += createOptionTag(tag, title);
	}
    alert(directionHTML);
    $("#popupDirection").html(directionHTML);
    $("#popupDirection").val(prefDirectionTag);
    
	changeDirection();
}

function changeStop() {
    savePrefs();
    updateUIRoutes();
    refreshTimes();
}

function createOptionTag (val, label) {
	return('<option value="' + val + '">' + label + '</option>');
}

// Creates timestamp for valid results
function createTimeStamp() {
	var d = new Date();
	var timeOfDay	= 'AM'; 
	var hour			= d.getHours();
	if (hour >= 12) {
		timeOfDay = 'PM';
		if (hour > 12)hour -= 12;
	}
	var min			= d.getMinutes();
	min = (min < 10) ? '0'+min : min;
	var day			= this.daysOfWeek[d.getDay()];
	var month 		= this.monthsOfYear[d.getMonth()];;
	var date			= d.getDate();
	return ('Valid as of ' + hour + ':' + min + ' ' + timeOfDay + ' ' + day + ', ' + month + ' ' + date);
}

function getCurrentRouteObject (){
	var l = routeList.length;
	var currentRoute;
	while(l--) {
		currentRoute = routeList[l];
		if(currentRoute.getRouteTag() == prefRouteTag) {
			return currentRoute;
        }
	}
    return null;
    
}

function getCurrentDirectionObject (){
	var currentRoute = getCurrentRouteObject();
	var directionList = currentRoute.getDirections();
	var l = directionList.length;
	var currentDirection;
	while(l--) {
		currentDirection = directionList[l];
		if(currentDirection.getDirectionTag() == prefDirectionTag) {
			return currentDirection;
        }
	}
    return null;
}

function openInBrowser(event) {
    if (window.widget) {
        widget.openURL('http://www.wirelust.com');
    }
}

//
// Function: hide()
// Called when the widget has been hidden
//
function hide() {
    // Stop any timers to prevent CPU usage
}

//
// Function: load()
// Called by HTML body element's onload event when the widget is ready to start
//
function load() {
    dashcode.setupParts();
    timerInterval = null;
    
	if (window.widget) {
		widgetId = widget.identifier; 

		// ROUTE
		if (widget.preferenceForKey(widgetId + '.routeTag') == undefined) {
			widget.setPreferenceForKey(DEF_ROUTE_TAG, widgetId + '.routeTag');
			widget.setPreferenceForKey(DEF_ROUTE_TITLE, widgetId + '.routeTitle');
		}
		if (widget.preferenceForKey(widgetId + '.routeTitle') == undefined) {
			widget.setPreferenceForKey(DEF_ROUTE_TAG, widgetId + '.routeTag');
			widget.setPreferenceForKey(DEF_ROUTE_TITLE, widgetId + '.routeTitle');
		}
		prefRouteTag = widget.preferenceForKey(widgetId + '.routeTag');
		prefRouteTitle = widget.preferenceForKey(widgetId + '.routeTitle');

		// DIRECTION
		if (widget.preferenceForKey(widgetId + '.directionTag') == undefined) {
			widget.setPreferenceForKey(DEF_DIR_TAG, widgetId + '.directionTag');
			widget.setPreferenceForKey(DEF_DIR_TITLE, widgetId + '.directionTitle');
		}
		if (widget.preferenceForKey(widgetId + '.directionTitle') == undefined) {
			widget.setPreferenceForKey(DEF_DIR_TAG, widgetId + '.directionTag');
			widget.setPreferenceForKey(DEF_DIR_TITLE, widgetId + '.directionTitle');
		}
		prefDirectionTag = widget.preferenceForKey(widgetId + '.directionTag');
		prefDirectionTitle = widget.preferenceForKey(widgetId + '.directionTitle');

		// STOP
		if (widget.preferenceForKey(widgetId + '.stopTag') == undefined) {
			widget.setPreferenceForKey(DEF_STOP_TAG, widgetId + '.stopTag');
			widget.setPreferenceForKey(DEF_STOP_TITLE, widgetId + '.stopTitle');
		}
		if (widget.preferenceForKey(widgetId + '.stopTitle') == undefined) {
			widget.setPreferenceForKey(DEF_STOP_TAG, widgetId + '.stopTag');
			widget.setPreferenceForKey(DEF_STOP_TITLE, widgetId + '.stopTitle');
		}
		prefStopTag = widget.preferenceForKey(widgetId + '.stopTag');
		prefStopTitle = widget.preferenceForKey(widgetId + '.stopTitle');

		
	} else {
        prefRouteTag = DEF_ROUTE_TAG;
        prefRouteTitle = DEF_ROUTE_TITLE;
        prefDirectionTag = DEF_DIR_TAG;
        prefDirectionTitle = DEF_DIR_TITLE;
        prefStopTag = DEF_STOP_TAG;
        prefStopTitle = DEF_STOP_TITLE;
	}
    
    $("#labelPrediction0").html("");
    $("#labelPrediction1").html("");
    $("#labelPrediction2").html("");
    $("#labelUpdate").html("");

    updateUIRoutes();
}

function refreshRoutes() {
	var xml_request = new XMLHttpRequest();
	var url = webserviceURLBase + "command=routeConfig";
	
	xml_request.onLoad = function(e) {
		//alert('onload');
	}
	xml_request.overrideMimeType("text/xml");
	
	xml_request.onreadystatechange=function() {
		if (xml_request.readyState==4) {
			refreshRoutesResponse(xml_request);
		}
	}
	//xml_request.setRequestHeader("Cache-Control", "no-cache");
	xml_request.open("GET", url);
	xml_request.send(null);
}

function refreshRoutesResponse(request) {
	routeList = new Array();
    var responseXML = request.responseXML;
    var root = responseXML.getElementsByTagName('body')[0];
    var routes = responseXML.getElementsByTagName('route');
	titleList = new Array();

    for (var i=0; i<routes.length; i++) {
        var currentRoute = routes[i];
        
        var tempRoute = new Route();
        tempRoute.setRouteTag(currentRoute.getAttribute('tag'));
        tempRoute.setRouteTitle(currentRoute.getAttribute('title'));
        
        var childNodes = currentRoute.childNodes;
        for (var r=0; r<childNodes.length; r++) {
            var child = childNodes[r];
            if (child.nodeName == "stop") {
                var thisStop = child;
                var thisDirTag = thisStop.getAttribute('dirTag');
                
                var tempDirection = tempRoute.getDirectionByTag(thisDirTag);
                if (tempDirection == null) {
                    var tempDirection = new Direction();
                    tempDirection.setDirectionTag(thisDirTag);
                    tempRoute.addDirection(tempDirection);
                }
                
                var tempStop = new Stop();
                tempStop.setStopTag(thisStop.getAttribute('tag'));
                tempStop.setStopTitle(thisStop.getAttribute('title'));
                tempDirection.addStop(tempStop);
            } else if (child.nodeName == "direction") {
                // we only care about the direction tags so we can get the titles.
                // dumb for boston since we only have two directions, but whateva.
                thisDirTag = child.getAttribute('tag');
                thisDirTitle = child.getAttribute('title');
                
                var tempDirection = tempRoute.getDirectionByTag(thisDirTag);
                if (tempDirection == null) {
                    var tempDirection = new Direction();
                    tempDirection.setDirectionTag(thisDirTag);
                    tempDirection.setDirectionTitle(thisDirTitle);
                    tempRoute.addDirection(tempDirection);
                } else {
                    tempDirection.setDirectionTitle(thisDirTitle);
                }
            }
        }
        
        routeList.push(tempRoute);
    }
        

	//////////////////////////////////////////////////////////////////////////
	
	var routeLength = routeList.length;
	var routeHTML = '';
	var tag; var title;
	while(routeLength--){
		tag = routeList[routeLength].getRouteTag();
		title = routeList[routeLength].getRouteTitle();
		routeHTML += createOptionTag(tag, title);
	}
    if ($("#popupRoute")) {
        $("#popupRoute").html(routeHTML);
        $("#popupRoute").val(prefRouteTag);
        changeRoute();
    }
}


function refreshTimes() {
	var url = predictionURLBase + 'stopId=' + prefStopTag;
	var xml_request = new XMLHttpRequest();
	xml_request.overrideMimeType("text/xml");
	
	xml_request.onreadystatechange=function() {
		if (xml_request.readyState == 4) {
            responseXML = xml_request.responseXML;
            var predictions = responseXML.getElementsByTagName('prediction');

            $("#labelPrediction0").html("");
            $("#labelPrediction1").html("");
            $("#labelPrediction2").html("");
            for (var i=0; i<predictions.length; i++) {
                mins = predictions[i].getAttribute('minutes');
                time = (mins) ? mins + ' minutes' : 'Unknown';
                if ($("#labelPrediction" + i)) {
                    $("#labelPrediction" + i).html(time);
                }
            }
	
            if ($("#labelTimestamp")) {
                $("#labelTimestamp").html(createTimeStamp());
            }
            
		}
	}
	xml_request.setRequestHeader("Cache-Control", "no-cache");
	xml_request.open("GET", url);
	xml_request.send(null);
}

//
// Function: remove()
// Called when the widget has been removed from the Dashboard
//
function remove() {
    // Stop any timers to prevent CPU usage
    // Remove any preferences as needed
    // widget.setPreferenceForKey(null, dashcode.createInstancePreferenceKey("your-key"));
}


//
// Function: show()
// Called when the widget has been shown
//
function show()
{
    // Restart any timers that were stopped on hide
    if (timerInterval == null) {
        timerInterval = setInterval(refreshTimes, 30000);
    }
    refreshTimes();
    
}

function savePrefs() {
	prefRouteTag = $("#popupRoute").val();
	prefRouteTitle = $("#popupRoute option:selected").text();

    //alert("route:" + prefRouteTag + " title:" + prefRouteTitle);
	if (window.widget) {
        widget.setPreferenceForKey(prefRouteTag, widgetId + '.routeTag');
        widget.setPreferenceForKey(prefRouteTitle, widgetId + '.routeTitle');
    }
    
    prefDirectionTag = $("#popupDirection").val();
	prefDirectionTitle = $("#popupDirection option:selected").text();

    //alert("direction:" + prefDirectionTag + " title:" + prefDirectionTitle);
	if (window.widget) {
        widget.setPreferenceForKey(prefDirectionTag, widgetId + '.directionTag');
        widget.setPreferenceForKey(prefDirectionTitle, widgetId + '.directionTitle');
    }
    
    prefStopTag = $("#popupStop").val();
	prefStopTitle = $("#popupStop option:selected").text();

    //alert("stop:" + prefStopTag + " title:" + prefStopTitle);
	if (window.widget) {
        widget.setPreferenceForKey(prefStopTag, widgetId + '.stopTag');
        widget.setPreferenceForKey(prefStopTitle, widgetId + '.stopTitle');
    }
}



//
// Function: sync()
// Called when the widget has been synchronized with .Mac
//
function sync()
{
    // Retrieve any preference values that you need to be synchronized here
    // Use this for an instance key's value:
    // instancePreferenceValue = widget.preferenceForKey(null, dashcode.createInstancePreferenceKey("your-key"));
    //
    // Or this for global key's value:
    // globalPreferenceValue = widget.preferenceForKey(null, "your-key");
}

//
// Function: showBack(event)
// Called when the info button is clicked to show the back of the widget
//
// event: onClick event from the info button
//
function showBack(event)
{
    var front = document.getElementById("front");
    var back = document.getElementById("back");

    if (window.widget) {
        widget.prepareForTransition("ToBack");
        refreshRoutes();
    }

    front.style.display = "none";
    back.style.display = "block";

    if (window.widget) {
        setTimeout('widget.performTransition();', 0);
    }
}

//
// Function: showFront(event)
// Called when the done button is clicked from the back of the widget
//
// event: onClick event from the done button
//
function showFront(event)
{
    var front = document.getElementById("front");
    var back = document.getElementById("back");

    if (window.widget) {
        widget.prepareForTransition("ToFront");
    }

    front.style.display="block";
    back.style.display="none";

    if (window.widget) {
        setTimeout('widget.performTransition();', 0);
    }
}

function updateUIRoutes() {
    $("#labelRoute").html("Route: " + prefRouteTitle);
    $("#labelDirection").html(prefDirectionTitle);
    $("#labelStop").html(prefStopTitle);
}


if (window.widget) {
    widget.onremove = remove;
    widget.onhide = hide;
    widget.onshow = show;
    widget.onsync = sync;
}

//===============================================================================================
// Config Objects
//===============================================================================================

//Route Object
Route = function() {
	this.$directions = new Array();
}
Route.prototype.setRouteTag = function(arg) {
	this.$routeTag = arg;
}
Route.prototype.getRouteTag = function(arg) {
	return this.$routeTag;
}
Route.prototype.setRouteTitle = function(arg) {
	this.$routeTitle = arg;
}
Route.prototype.getRouteTitle = function(arg) {
	return this.$routeTitle;
}
Route.prototype.addDirection = function(arg) {
	this.$directions.push(arg);
}
Route.prototype.getDirections = function(arg) {
	return this.$directions;
}
Route.prototype.getDirectionByTag = function(arg) {
    for (var i=0; i<this.$directions.length; i++) {
        if (this.$directions[i].getDirectionTag() == arg) {
            return this.$directions[i];
        }
    }
    return null;
}


//Direction Object
Direction = function() {
	this.$stops = new Array();
}
Direction.prototype.setDirectionTag = function(arg) {
	this.$directionTag = arg;
}
Direction.prototype.getDirectionTag = function(arg) {
	return this.$directionTag;
}
Direction.prototype.setDirectionTitle = function(arg) {
	this.$directionTitle = arg;
}
Direction.prototype.getDirectionTitle = function(arg) {
	return this.$directionTitle;
}
Direction.prototype.addStop = function(arg) {
	this.$stops.push(arg);
}
Direction.prototype.getStops = function(arg) {
	return this.$stops;
}

//Stop Object
Stop = function() {}
Stop.prototype.setStopTag = function(arg) {
	this.$stopTag = arg;
}
Stop.prototype.getStopTag = function(arg) {
	return this.$stopTag;
}
Stop.prototype.setStopTitle = function(arg) {
	this.$stopTitle = arg;
}
Stop.prototype.getStopTitle = function(arg) {
    return this.$stopTitle;
}



