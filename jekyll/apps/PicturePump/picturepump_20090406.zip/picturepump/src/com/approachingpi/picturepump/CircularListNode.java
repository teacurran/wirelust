package com.approachingpi.picturepump;

/**
 * Created by IntelliJ IDEA.
 * User: terrence
 * Date: Aug 19, 2004
 * Time: 11:55:20 PM
 * To change this template use Options | File Templates.
 */
public class CircularListNode {
	Object o;
	CircularListNode next;
	CircularListNode previous;
}
