package com.approachingpi.picturepump;

/**
 * Created by IntelliJ IDEA.
 * User: terrence
 * Date: Aug 20, 2004
 * Time: 11:03:24 PM
 * To change this template use Options | File Templates.
 */
public class SearchPage {
	public String url;
	public int start;
}
