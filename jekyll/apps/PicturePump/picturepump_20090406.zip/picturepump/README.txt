Google Image Grabber Thinger
8/23/2004

Requirements
Java J2SE 1.4.0+
http://java.sun.com/j2se

Running:
1. Extract all files into a single folder

2.	Windows:
	Double Click on "run_windows.bat"
 
	Macintosh (OSX Only):
	Double click on "googleimagegrab.jar"

	Linux:
	java -jar googleimagegrab.jar 

3. enjoy

New in this Version:
- New thread management to limit the number of consecutive threads loaded (for slower connections)
- GUI components Max Threads and Size now work
- Search now properly works for two consecutive searches
- settings are saved and loaded again next time app is run

Known Issues:
- Files that end in four character extentions will get named wrong (image.JPEG gets saved as imageJPEG)
- Stop button doesn't work

TODO:

absolute must:
- fix issues listed above
- Generate Log file of images downloaded

nice to have features:
- Add option to search only color, or only black and white images
- Add option to change the web browser application masquerades as to better avoid detection
- Add padding around search box
- Add cancel/stop button
- Splash screen with El33+ Ansi Graphics
- Think of a name for this thing
- about box

